 const routes = require('express').Router();
 const {controller, getProductDetails, updateStock} = require('../controller/result_controller');

 (()=>{
    post_request()
    get_request()
    patch_request()
 })();

 function post_request(){
    routes.post("/invetoryProduct",controller)
    // routes.post("/status",postPaymentStatus)
 }
 function patch_request(){
    routes.patch("/updatestock",updateStock)



 }
 function get_request(){
    routes.get("/product",getProductDetails) 
    
    
 }

module.exports = routes