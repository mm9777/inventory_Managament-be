const moduleSchema = require('../model/module_schema')
const stockSchema = require('../model/stockSchema')
const billSchema = require('../model/billSchema')

exports.controller = async(req, res)=>{
    console.log(req.body)
    const {product,quantity} = req.body
    let data={product,quantity}
    stockSchema(data).save()
    moduleSchema(req.body).save(async (err, result) => {
        
        if (err) {
          next(new Error("Data not saved"));}
          else{
          res.status(200).send({result})
        }
        })
    
}
exports.getProductDetails = async (req, res)=>{ 
    const {product,quantity,payment,name} = req.query
    billSchema(req.query).save()
    console.log(product,quantity,payment,name)
    let data ={
        product:product,
        gst : "5%",
        amount :10,
        quantity : quantity,
        date : new Date(),
        discount : 10,
        payment : payment,
        status :"success",
        billing_to:name
        
    }
    let result = await moduleSchema.findOne({product})
    let myprice = (result.myprice/result.quantity)*quantity
    console.log(myprice,"price")
    let pricewithgst = (myprice*5/100+myprice);
    console.log("priceGst",pricewithgst)
    let resPrice = pricewithgst- (pricewithgst*10/100)
    console.log("final price",resPrice)
    data.amount=resPrice
   
    

    res.status(200).send({data})
}
exports.updateStock = async(req, res)=>{
    let  {product,quantity,amount} = req.body
    //  console.log(product,quantity,status,amount)

    // let result = await moduleSchema.findOneAndUpdate({product},{status})
    // let stock = await stockSchema.findOne({product})
    let productDetail= await moduleSchema.findOne({product})
    let myprice = (productDetail.myprice)-(amount)
    priceAccount  = (productDetail.price)/(productDetail.quantity)
    // let price = (productDetail.price) - (custemorquantity*priceAccount)
    
    // console.log("amount remaining",myprice)
    let productQuantity = await billSchema.findOne({product})
    custemorquantity = (productQuantity.quantity)
    console.log("ssssss",custemorquantity)
    let price = (productDetail.price) - (custemorquantity*priceAccount)
    console.log("aaaaaaaa",priceAccount)
     
     quantity =  productDetail.quantity -quantity
     console.log(quantity)

    //  stockquantity = quantity-custemorquantity
    //  console.log("mmmmm",stockquantity)
    //  console.log("stockQuantity",quantity)
      
    // let produ = await moduleSchema.findOne({product})
    // profit = parseInt(produ.myprice - produ.price)
    

     
    if(quantity<=custemorquantity){
        res.send(`i have product quantity: ${ quantity}`);
    }
    
     
    //  else if(quantity<0){
    //     res.send(`product is not available`)
    // }
    
    else{
    

       const resData = await moduleSchema.findOneAndUpdate({product},{$set:{quantity,myprice,price}},{new:true})
        if(resData) res.send({resData})
        else res.send({err:"err occured"})
    
    }
}