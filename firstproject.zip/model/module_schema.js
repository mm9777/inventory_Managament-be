const mongoose = require('mongoose')
const add_schema = new mongoose.Schema({
    product:{
        type:String,
        require:true,
    },
    price:{
        type:Number,
        require:true,
    },
    quantity:{
        type:Number,
        min:0,
        require:true,
    }, 
    unit:{
        type:String,
        require:true,
    },
    myprice:{
        type:Number,
        require:true,
    },
    myunit:{
        type:String,
        require:true,
    },
    updated_on:{
        type: Date,
        default : new Date()
    }
    
})
const moduleSchema = mongoose.model("module_schema",add_schema);


    

module.exports = moduleSchema
